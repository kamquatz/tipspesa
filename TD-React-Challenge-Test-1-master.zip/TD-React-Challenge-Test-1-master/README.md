## Info

## Info
...
## How to test the app
- Clone this repository to your local machine
- Install dependencies `yarn install`
- Start the application `yarn start` The magic happens on port 3000

## Demo
Link to Demo App: https://seunzone.github.io/TD-React-Challenge-Test-1/
